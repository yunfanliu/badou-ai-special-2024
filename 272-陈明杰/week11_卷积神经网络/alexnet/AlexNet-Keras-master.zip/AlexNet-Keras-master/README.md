# AlexNet-Keras
这是一个使用Keras实现AlexNet的模型  
This is a example about AlexNet implement in Keras
# 使用方法Usage
## 训练train
我们需要下载猫狗数据集进行训练，运行train.py即可训练。  
We need to download the cat vs dog dataset for training, and run train.py to train.  
训练完后就会在logs里面出现模型。  
After the training, the model will appear in the logs.
## 预测predict
将predict.py里面的模型路径改成logs里面的模型路径即可预测。  
Change the model path in predict.py to the model path in logs to predict.
